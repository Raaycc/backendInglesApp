<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePalavrasNoBancoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "among",
            "traducao" => "entre"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "against",
            "traducao" => "de encontro"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "away",
            "traducao" => "afastado"
        ]);
        
        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "being",
            "traducao" => "sendo"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "came",
            "traducao" => "veio"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "better",
            "traducao" => "melhor"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "come",
            "traducao" => "vindo"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "could",
            "traducao" => "poderia, ser capaz de"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "even",
            "traducao" => "mesmo, até"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "ever",
            "traducao" => "sempre"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "eyes",
            "traducao" => "olhos"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "face",
            "traducao" => "cara"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "far",
            "traducao" => "distante"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "few",
            "traducao" => "poucos"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "gave",
            "traducao" => "deu, dar"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "give",
            "traducao" => "dar, fornecer"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "got",
            "traducao" => "obteve"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "had",
            "traducao" => "teve"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "hand",
            "traducao" => "mão"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "however",
            "traducao" => "entretanto"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "just",
            "traducao" => "apenas"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "less",
            "traducao" => "menos"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "let",
            "traducao" => "deixar"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "made",
            "traducao" => "feito"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "make",
            "traducao" => "fazer"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "may",
            "traducao" => "maio, poder"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "might",
            "traducao" => "poderia, poder"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "must",
            "traducao" => "obrigação, dever"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "once",
            "traducao" => "uma vez"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "own",
            "traducao" => "possuir, próprio"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "perhaps",
            "traducao" => "possivelmente, talvez"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "same",
            "traducao" => "mesmos"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "saw",
            "traducao" => "serra"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "seemed",
            "traducao" => "pareceu"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "shall",
            "traducao" => "deve"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "since",
            "traducao" => "desde, desde que"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "some",
            "traducao" => "algum, alguma"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "son",
            "traducao" => "filho"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "still",
            "traducao" => "ainda"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "tell",
            "traducao" => "dizer"
        ]);

        app(\App\Services\PalavrasService::class)->adicionar([
            "palavra" => "tell",
            "traducao" => "dizer"
        ]);

        

            


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('palavras_no_banco');
    }
}
