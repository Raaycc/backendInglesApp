<?php

namespace App\Services;

use App\Palavras;

class PalavrasService
{
    public function adicionar(array $data){
        Palavras::query()->create($data);
    }

    public function adicionara($data){
        
    }
}